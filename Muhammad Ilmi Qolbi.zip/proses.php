<?php    
echo $_POST['nama'];    //echo untuk menampilkan hasil
echo "<br />";    //untuk ganti baris agar tidak menjadi satu kesatuan kalimat yang berjajar
echo $_POST['email']; 
?>