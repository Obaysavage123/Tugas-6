<?php    
$a='Saya Sedang belajar PHP';    //mendeklarasikan variabel yang sudah diberi nilai dalam bentuk teks
$b=5;      //mendeklarasikan variabel yang sudah diberi nilai
/*fungsi print atau echo untuk menampilkan nilai atau isi dari variabel*/
print $a;     
echo $b;
 ?> 

 