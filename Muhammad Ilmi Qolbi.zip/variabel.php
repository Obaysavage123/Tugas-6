<!DOCTYPE html!>
<!--pembuka tag html-->
<html>
    <body>

<?php    
$i;    //mendeklarasikan variabel
$nama;    
$Umur;    
$_lokasi_memori;    
$ANGKA_MAKSIMUM;  
?> 

</body>
</html>
<!--Tag penutup html-->
